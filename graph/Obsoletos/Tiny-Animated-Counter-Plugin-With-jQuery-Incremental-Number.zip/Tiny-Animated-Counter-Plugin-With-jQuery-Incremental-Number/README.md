Documentation
-------------------
IncrementalNumber is a JQuery library for anyone who wants an Incremental animation of a number.
<br> 
For examples view index.html

<h1>How to use</h1>

Download and add to your code <b>Jquery</b>. <br>
Download and add to your code <b>incrementalNumber.js</b> <br>
Run function <b>incrementalNumber()</b> when document ready. <br>

<br>
Options
<br>
If the number is to big, you can add the parameter big-Number and de count start 10% less the total.
<br>
&lt;span class="incrementalNumber" big-number data-value="2123"&gt;&lt;/span&gt;

<br><br>
If the number is more big, you can especificate the start number like this: 
<br>
&lt;span class="incrementalNumber" big-number="19800" data-value="20000"&gt;&lt;/span&gt;
<br><br>

You can add text to the end with the parameter set-text 
<br>
&lt;span class="incrementalNumber" set-text="%" data-value="100"&gt;&lt;/span&gt;
<br><br>

The last option can set the total time of the "animate" with set-time in ms 
<br>
&lt;span class="incrementalNumber" set-time="3000" data-value="100"&gt;&lt;/span&gt;
<br><br>

If the numer is to big, this may not work. You have to use big-number also to make it.
<br>
This is all. Hope you like it. 

<br>
Barto!
